sudo ./pwmd &
