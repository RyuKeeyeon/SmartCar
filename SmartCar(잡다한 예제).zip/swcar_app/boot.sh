sleep 3
cd /home/pi/swcar_app
./led_ip
sudo ./pwmd &
