import cv2
import numpy as np


def main():
    camera = cv2.VideoCapture(0)
    camera.set(3, 160)
    camera.set(4, 120)

    while (camera.isOpened()):
        ret, frame = camera.read()
        cv2.imshow('normal', frame)
        crop_img = frame[60:120, 0:160]
        gray = cv2.cvtColor(crop_img, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        ret, thresh1 = cv2.threshold(blur, 123, 255, cv2.THRESH_BINARY_INV)

        cv2.imshow('thresh1', thresh1)
        if cv2.waitKey(1) == ord('q'):
            break
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()